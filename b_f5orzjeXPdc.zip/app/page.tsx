'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Mail, MapPin, Phone, Facebook, Twitter, Instagram } from 'lucide-react';

export default function EmailTemplate() {
  return (
    <div className="bg-gray-100 min-h-screen py-8 px-4">
      <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
        {/* Header */}
        <header className="bg-gradient-to-r from-red-600 to-orange-500 text-white px-6 py-6 text-center">
          <h1 className="text-4xl font-bold">QuickBite</h1>
          <p className="text-orange-100 text-sm mt-2">Fast. Fresh. Delicious.</p>
        </header>

        {/* Hero Section */}
        <section className="relative h-64 md:h-80 overflow-hidden">
          <Image
            src="/hero-banner.jpg"
            alt="Delicious food banner"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
            <div className="text-center text-white">
              <h2 className="text-4xl md:text-5xl font-bold mb-2">Get 30% OFF</h2>
              <p className="text-xl md:text-2xl">on your first order 🍔</p>
            </div>
          </div>
        </section>

        {/* CTA Button Section */}
        <section className="px-6 py-8 text-center bg-gradient-to-b from-white to-gray-50">
          <Link href="/signup">
            <button className="bg-gradient-to-r from-red-600 to-orange-500 text-white px-8 py-4 rounded-full font-bold text-lg shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300 mb-4">
              Order Now
            </button>
          </Link>
          <p className="text-gray-600 text-sm">Limited time offer - Valid for first-time users only</p>
        </section>

        {/* Featured Items Section */}
        <section className="px-6 py-12 bg-white">
          <h3 className="text-3xl font-bold text-gray-800 mb-8 text-center">Featured Favorites</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Burger Card */}
            <div className="bg-gradient-to-b from-gray-50 to-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow">
              <div className="relative h-48 w-full">
                <Image
                  src="/burger.jpg"
                  alt="Gourmet Burger"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-4">
                <h4 className="text-lg font-bold text-gray-800 mb-2">Gourmet Burger</h4>
                <p className="text-gray-600 text-sm mb-3">Premium beef patty with fresh lettuce, tomato, and special sauce</p>
                <p className="text-red-600 font-bold text-lg">$12.99</p>
              </div>
            </div>

            {/* Pizza Card */}
            <div className="bg-gradient-to-b from-gray-50 to-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow">
              <div className="relative h-48 w-full">
                <Image
                  src="/pizza.jpg"
                  alt="Classic Pizza"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-4">
                <h4 className="text-lg font-bold text-gray-800 mb-2">Classic Pizza</h4>
                <p className="text-gray-600 text-sm mb-3">Hand-tossed dough with mozzarella, pepperoni, and fresh vegetables</p>
                <p className="text-red-600 font-bold text-lg">$14.99</p>
              </div>
            </div>

            {/* Ramen Card */}
            <div className="bg-gradient-to-b from-gray-50 to-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow">
              <div className="relative h-48 w-full">
                <Image
                  src="/ramen.jpg"
                  alt="Asian Ramen"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-4">
                <h4 className="text-lg font-bold text-gray-800 mb-2">Asian Ramen</h4>
                <p className="text-gray-600 text-sm mb-3">Authentic ramen with rich broth, noodles, and traditional toppings</p>
                <p className="text-red-600 font-bold text-lg">$11.99</p>
              </div>
            </div>
          </div>
        </section>

        {/* Promotional Offer Section */}
        <section className="mx-6 my-8 bg-gradient-to-r from-red-50 to-orange-50 border-2 border-red-200 rounded-lg p-8 text-center">
          <h3 className="text-2xl font-bold text-red-700 mb-3">Special Promotion</h3>
          <p className="text-gray-700 mb-4">Order over $25 and get FREE delivery! 🚚</p>
          <div className="bg-white rounded-lg p-4 border-2 border-red-500 inline-block">
            <p className="text-gray-600 text-sm">Use code:</p>
            <p className="text-3xl font-bold text-red-600">QUICKBITE30</p>
          </div>
        </section>

        {/* Testimonial Section */}
        <section className="px-6 py-12 bg-gray-50">
          <h3 className="text-2xl font-bold text-gray-800 mb-8 text-center">What Our Customers Say</h3>
          <div className="max-w-2xl mx-auto bg-white rounded-lg p-8 shadow-md border-l-4 border-orange-500">
            <p className="text-gray-700 text-lg mb-4 italic">"QuickBite has completely changed how I order food! Fast delivery, hot meals, and amazing prices. I can't recommend them enough!"</p>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-red-400 to-orange-400 rounded-full flex items-center justify-center text-white font-bold text-lg">
                SJ
              </div>
              <div>
                <p className="font-bold text-gray-800">Sarah Johnson</p>
                <p className="text-yellow-500">★★★★★</p>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-gray-800 text-white px-6 py-10">
          <div className="max-w-2xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              {/* Contact Info */}
              <div>
                <h4 className="font-bold text-lg mb-4">Contact Us</h4>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Phone size={18} className="text-orange-500" />
                    <span>(555) 123-4567</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Mail size={18} className="text-orange-500" />
                    <span>hello@quickbite.com</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <MapPin size={18} className="text-orange-500" />
                    <span>123 Food Street, Flavor City, FC 12345</span>
                  </div>
                </div>
              </div>

              {/* Social Media */}
              <div>
                <h4 className="font-bold text-lg mb-4">Follow Us</h4>
                <div className="flex gap-4">
                  <a href="#" className="bg-orange-500 hover:bg-orange-600 p-3 rounded-full transition-colors">
                    <Facebook size={20} />
                  </a>
                  <a href="#" className="bg-orange-500 hover:bg-orange-600 p-3 rounded-full transition-colors">
                    <Twitter size={20} />
                  </a>
                  <a href="#" className="bg-orange-500 hover:bg-orange-600 p-3 rounded-full transition-colors">
                    <Instagram size={20} />
                  </a>
                </div>
              </div>
            </div>

            {/* Footer Bottom */}
            <div className="border-t border-gray-700 pt-6 text-center text-gray-400 text-sm">
              <p className="mb-4">© 2024 QuickBite. All rights reserved.</p>
              <a href="#" className="text-orange-500 hover:text-orange-400 transition-colors">
                Unsubscribe
              </a>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
