'use client';

import { useState } from 'react';
import { ArrowLeft, Eye, EyeOff, Mail, Phone, Smartphone } from 'lucide-react';
import Link from 'next/link';

type Step = 'welcome' | 'auth-options' | 'signup' | 'otp' | 'success';

export default function SignupFlow() {
  const [step, setStep] = useState<Step>('welcome');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [otp, setOtp] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [otpTimer, setOtpTimer] = useState(60);
  const [canResendOtp, setCanResendOtp] = useState(false);

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const getPasswordStrength = (pwd: string) => {
    if (pwd.length === 0) return { strength: 'none', color: 'bg-gray-300', text: '' };
    if (pwd.length < 6) return { strength: 'weak', color: 'bg-red-500', text: 'Weak' };
    if (pwd.length < 10) return { strength: 'medium', color: 'bg-yellow-500', text: 'Medium' };
    return { strength: 'strong', color: 'bg-green-500', text: 'Strong' };
  };

  const handleWelcomeStart = () => {
    setStep('auth-options');
  };

  const handleSignupEmail = () => {
    const newErrors: Record<string, string> = {};
    if (!name.trim()) newErrors.name = 'Name is required';
    if (!email.trim()) newErrors.email = 'Email is required';
    if (email && !validateEmail(email)) newErrors.email = 'Invalid email format';
    if (!password) newErrors.password = 'Password is required';
    if (password.length < 6) newErrors.password = 'Password must be at least 6 characters';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setOtpTimer(60);
    setCanResendOtp(false);
    setStep('otp');

    // Simulate OTP timer
    const timer = setInterval(() => {
      setOtpTimer((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setCanResendOtp(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleVerifyOtp = () => {
    const newErrors: Record<string, string> = {};
    if (!otp.trim()) newErrors.otp = 'OTP is required';
    if (otp && otp.length !== 6) newErrors.otp = 'OTP must be 6 digits';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setStep('success');
  };

  const handleResendOtp = () => {
    setOtpTimer(60);
    setCanResendOtp(false);
    const timer = setInterval(() => {
      setOtpTimer((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setCanResendOtp(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const goBack = () => {
    if (step === 'auth-options') setStep('welcome');
    if (step === 'signup') setStep('auth-options');
    if (step === 'otp') setStep('signup');
  };

  const getProgress = () => {
    const steps: Record<Step, number> = {
      welcome: 1,
      'auth-options': 1,
      signup: 2,
      otp: 3,
      success: 3,
    };
    return steps[step];
  };

  const passwordStrength = getPasswordStrength(password);

  return (
    <div className="bg-gradient-to-br from-red-50 to-orange-50 min-h-screen flex items-center justify-center py-12 px-4">
      <div className="w-full max-w-md">
        {/* Progress Indicator */}
        {step !== 'welcome' && step !== 'success' && (
          <div className="mb-8">
            <div className="flex justify-between mb-2">
              <span className="text-sm font-semibold text-gray-600">
                Step {getProgress()} of 3
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-red-600 to-orange-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${(getProgress() / 3) * 100}%` }}
              ></div>
            </div>
          </div>
        )}

        {/* Welcome Screen */}
        {step === 'welcome' && (
          <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-red-600 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <span className="text-2xl font-bold text-white">QB</span>
            </div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">QuickBite</h1>
            <p className="text-gray-600 mb-2">Fast. Fresh. Delicious.</p>
            <p className="text-gray-500 text-sm mb-8">Order your favorite food in seconds</p>
            <button
              onClick={handleWelcomeStart}
              className="w-full bg-gradient-to-r from-red-600 to-orange-500 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all hover:scale-105"
            >
              Get Started
            </button>
            <p className="text-gray-600 text-sm mt-6">
              Already have an account?{' '}
              <a href="#" className="text-red-600 font-semibold hover:text-red-700">
                Login
              </a>
            </p>
          </div>
        )}

        {/* Auth Options Screen */}
        {step === 'auth-options' && (
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="flex items-center mb-8">
              <button
                onClick={goBack}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft size={20} className="text-gray-600" />
              </button>
              <h2 className="text-2xl font-bold text-gray-800 flex-1 text-center">Sign Up</h2>
              <div className="w-10"></div>
            </div>

            <div className="space-y-4">
              <button
                onClick={() => setStep('signup')}
                className="w-full border-2 border-red-600 text-red-600 py-3 rounded-xl font-semibold hover:bg-red-50 transition-colors flex items-center justify-center gap-2"
              >
                <Mail size={20} />
                Continue with Email
              </button>
              <button className="w-full border-2 border-gray-300 text-gray-700 py-3 rounded-xl font-semibold hover:bg-gray-50 transition-colors flex items-center justify-center gap-2">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-5 h-5">
                  <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.5"/>
                  <circle cx="12" cy="12" r="3" fill="currentColor"/>
                </svg>
                Continue with Google
              </button>
              <button className="w-full border-2 border-gray-300 text-gray-700 py-3 rounded-xl font-semibold hover:bg-gray-50 transition-colors flex items-center justify-center gap-2">
                <Phone size={20} />
                Continue with Phone
              </button>
            </div>
          </div>
        )}

        {/* Signup Screen */}
        {step === 'signup' && (
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="flex items-center mb-8">
              <button
                onClick={goBack}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft size={20} className="text-gray-600" />
              </button>
              <h2 className="text-2xl font-bold text-gray-800 flex-1 text-center">Create Account</h2>
              <div className="w-10"></div>
            </div>

            <div className="space-y-5">
              {/* Name Field */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Full Name
                </label>
                <input
                  type="text"
                  placeholder="John Doe"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (errors.name) setErrors({ ...errors, name: '' });
                  }}
                  className={`w-full px-4 py-2 border-2 rounded-lg focus:outline-none transition-colors ${
                    errors.name ? 'border-red-500' : 'border-gray-300 focus:border-red-600'
                  }`}
                />
                {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
              </div>

              {/* Email Field */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Email</label>
                <input
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (errors.email) setErrors({ ...errors, email: '' });
                  }}
                  className={`w-full px-4 py-2 border-2 rounded-lg focus:outline-none transition-colors ${
                    errors.email ? 'border-red-500' : 'border-gray-300 focus:border-red-600'
                  }`}
                />
                {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
              </div>

              {/* Password Field */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Password</label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      if (errors.password) setErrors({ ...errors, password: '' });
                    }}
                    className={`w-full px-4 py-2 pr-10 border-2 rounded-lg focus:outline-none transition-colors ${
                      errors.password ? 'border-red-500' : 'border-gray-300 focus:border-red-600'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-600 hover:text-gray-800"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>

                {/* Password Strength */}
                {password && (
                  <div className="mt-2">
                    <div className="flex gap-1 mb-1">
                      <div
                        className={`h-1 flex-1 rounded-full ${
                          ['weak', 'medium', 'strong'].includes(passwordStrength.strength)
                            ? passwordStrength.color
                            : 'bg-gray-300'
                        }`}
                      ></div>
                      <div
                        className={`h-1 flex-1 rounded-full ${
                          ['medium', 'strong'].includes(passwordStrength.strength)
                            ? passwordStrength.color
                            : 'bg-gray-300'
                        }`}
                      ></div>
                      <div
                        className={`h-1 flex-1 rounded-full ${
                          passwordStrength.strength === 'strong' ? passwordStrength.color : 'bg-gray-300'
                        }`}
                      ></div>
                    </div>
                    <p className={`text-xs font-semibold ${
                      passwordStrength.strength === 'weak' ? 'text-red-500' :
                      passwordStrength.strength === 'medium' ? 'text-yellow-500' :
                      'text-green-500'
                    }`}>
                      {passwordStrength.text}
                    </p>
                  </div>
                )}

                {errors.password && <p className="text-red-500 text-sm mt-1">{errors.password}</p>}
              </div>

              <button
                onClick={handleSignupEmail}
                className="w-full bg-gradient-to-r from-red-600 to-orange-500 text-white py-3 rounded-lg font-semibold hover:shadow-lg transition-all hover:scale-105"
              >
                Continue
              </button>

              <p className="text-gray-600 text-sm text-center">
                Already have an account?{' '}
                <a href="#" className="text-red-600 font-semibold hover:text-red-700">
                  Login
                </a>
              </p>
            </div>
          </div>
        )}

        {/* OTP Screen */}
        {step === 'otp' && (
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="flex items-center mb-8">
              <button
                onClick={goBack}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft size={20} className="text-gray-600" />
              </button>
              <h2 className="text-2xl font-bold text-gray-800 flex-1 text-center">Verify OTP</h2>
              <div className="w-10"></div>
            </div>

            <p className="text-gray-600 text-center mb-6">
              We&apos;ve sent a 6-digit code to {email}
            </p>

            <div className="space-y-5">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Enter OTP Code
                </label>
                <input
                  type="text"
                  placeholder="000000"
                  maxLength={6}
                  value={otp}
                  onChange={(e) => {
                    setOtp(e.target.value.replace(/\D/g, ''));
                    if (errors.otp) setErrors({ ...errors, otp: '' });
                  }}
                  className={`w-full px-4 py-3 border-2 rounded-lg text-center text-2xl tracking-widest focus:outline-none transition-colors font-mono ${
                    errors.otp ? 'border-red-500' : 'border-gray-300 focus:border-red-600'
                  }`}
                />
                {errors.otp && <p className="text-red-500 text-sm mt-1">{errors.otp}</p>}
              </div>

              <button
                onClick={handleVerifyOtp}
                className="w-full bg-gradient-to-r from-red-600 to-orange-500 text-white py-3 rounded-lg font-semibold hover:shadow-lg transition-all hover:scale-105"
              >
                Verify OTP
              </button>

              {canResendOtp ? (
                <button
                  onClick={handleResendOtp}
                  className="w-full text-red-600 font-semibold hover:text-red-700 transition-colors"
                >
                  Resend OTP
                </button>
              ) : (
                <p className="text-center text-gray-600 text-sm">
                  Resend OTP in <span className="font-semibold">{otpTimer}s</span>
                </p>
              )}
            </div>
          </div>
        )}

        {/* Success Screen */}
        {step === 'success' && (
          <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <span className="text-3xl">✓</span>
            </div>
            <h2 className="text-3xl font-bold text-gray-800 mb-2">Welcome, {name}!</h2>
            <p className="text-gray-600 mb-8">Your account has been created successfully.</p>
            <button
              onClick={() => setStep('welcome')}
              className="w-full bg-gradient-to-r from-red-600 to-orange-500 text-white py-3 rounded-lg font-semibold hover:shadow-lg transition-all hover:scale-105"
            >
              Start Ordering
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
